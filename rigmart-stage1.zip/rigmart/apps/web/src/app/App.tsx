import { SystemCheck } from './SystemCheck';

/**
 * Этап 1: временно показывает экран технической проверки.
 * На этапе 2 здесь появятся роутер (/en/, /ru/ ...), i18n и layout.
 */
export function App() {
  return <SystemCheck />;
}
