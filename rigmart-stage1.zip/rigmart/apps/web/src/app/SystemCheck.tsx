import { useEffect, useState } from 'react';
import {
  SUPPORTED_LOCALES,
  LOCALE_NATIVE_NAME,
  formatPrice,
  type HealthResponse,
} from '@rigmart/shared';

/*
 * Технический экран этапа 1 (для разработчика, не для покупателей).
 * Проверяет: сайт собирается, shared-пакет подключён, API отвечает.
 * Будет удалён на этапе 2 — поэтому тексты здесь пока без i18n.
 */

type ApiState =
  | { kind: 'loading' }
  | { kind: 'ok'; data: HealthResponse }
  | { kind: 'error'; message: string };

const SAMPLE_PRICE_CENTS = 199_900;

export function SystemCheck() {
  const [api, setApi] = useState<ApiState>({ kind: 'loading' });

  useEffect(() => {
    const controller = new AbortController();
    fetch('/api/health', { signal: controller.signal })
      .then(async (res) => {
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        setApi({ kind: 'ok', data: (await res.json()) as HealthResponse });
      })
      .catch((err: unknown) => {
        if (controller.signal.aborted) return;
        setApi({ kind: 'error', message: err instanceof Error ? err.message : String(err) });
      });
    return () => controller.abort();
  }, []);

  return (
    <main className="mx-auto flex min-h-dvh max-w-xl flex-col justify-center gap-10 px-6 py-16">
      <div className="flex items-center gap-4">
        <img src="/brand/logo-mark.png" alt="" width={56} height={56} className="size-14" />
        <div>
          <p className="text-2xl font-semibold tracking-tight">RIGMART</p>
          <p className="text-fg-muted text-sm">Stage 1 system check</p>
        </div>
      </div>

      <dl className="border-line divide-line bg-ink-900 divide-y rounded-2xl border text-sm">
        <Row label="Web (Vite + React + Tailwind)" value="Running" ok />
        <Row
          label="API /api/health"
          value={
            api.kind === 'loading'
              ? 'Checking…'
              : api.kind === 'ok'
                ? `OK · v${api.data.version}`
                : `Unavailable (${api.message})`
          }
          ok={api.kind === 'ok'}
          pending={api.kind === 'loading'}
        />
        <Row label="Shared package" value="Linked" ok />
      </dl>

      <section className="flex flex-col gap-3">
        <h2 className="text-fg-muted text-sm">Price formatting per locale</h2>
        <ul className="border-line bg-ink-900 grid gap-px overflow-hidden rounded-2xl border text-sm">
          {SUPPORTED_LOCALES.map((locale) => (
            <li key={locale} className="flex justify-between px-5 py-3">
              <span className="text-fg-muted">{LOCALE_NATIVE_NAME[locale]}</span>
              <span className="tabular-nums">{formatPrice(SAMPLE_PRICE_CENTS, locale)}</span>
            </li>
          ))}
        </ul>
      </section>
    </main>
  );
}

function Row({
  label,
  value,
  ok,
  pending = false,
}: {
  label: string;
  value: string;
  ok: boolean;
  pending?: boolean;
}) {
  const dot = pending ? 'bg-fg-muted animate-pulse' : ok ? 'bg-cyan-500' : 'bg-red-500';
  return (
    <div className="flex items-center justify-between gap-4 px-5 py-4">
      <dt className="text-fg-muted">{label}</dt>
      <dd className="flex items-center gap-2 text-right">
        <span className={`size-2 rounded-full ${dot}`} aria-hidden />
        {value}
      </dd>
    </div>
  );
}
