import { fileURLToPath, URL } from 'node:url';
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';

export default defineConfig({
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url)),
    },
  },
  server: {
    port: 5173,
    // Запросы /api/* с сайта уходят на Express-сервер
    proxy: {
      '/api': 'http://localhost:4000',
    },
  },
  preview: {
    port: 5173,
  },
});
