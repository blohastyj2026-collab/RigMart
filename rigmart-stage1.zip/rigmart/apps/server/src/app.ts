import express, { type ErrorRequestHandler } from 'express';
import type { ApiError } from '@rigmart/shared';
import { healthRouter } from './routes/health.js';

export function createApp() {
  const app = express();

  app.disable('x-powered-by');
  app.use(express.json({ limit: '1mb' }));

  app.use('/api/health', healthRouter);

  app.use('/api', (_req, res) => {
    const body: ApiError = { error: { code: 'NOT_FOUND', message: 'Endpoint not found' } };
    res.status(404).json(body);
  });

  const errorHandler: ErrorRequestHandler = (err, _req, res, _next) => {
    console.error(err);
    const body: ApiError = { error: { code: 'INTERNAL', message: 'Internal server error' } };
    res.status(500).json(body);
  };
  app.use(errorHandler);

  return app;
}
