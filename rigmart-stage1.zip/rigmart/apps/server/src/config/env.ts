import { z } from 'zod';

/**
 * Все настройки сервера читаются и проверяются в одном месте.
 * Если чего-то не хватает — сервер сразу скажет, чего именно.
 */
const envSchema = z.object({
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
  PORT: z.coerce.number().int().positive().default(4000),
  // Понадобится с этапа 7 (Prisma). Сейчас необязателен.
  DATABASE_URL: z.string().url().optional(),
});

const parsed = envSchema.safeParse(process.env);

if (!parsed.success) {
  console.error('Invalid server environment variables:');
  console.error(parsed.error.flatten().fieldErrors);
  process.exit(1);
}

export const env = parsed.data;
