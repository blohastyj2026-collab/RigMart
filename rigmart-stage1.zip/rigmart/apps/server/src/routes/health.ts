import { Router } from 'express';
import type { HealthResponse } from '@rigmart/shared';

export const healthRouter = Router();

healthRouter.get('/', (_req, res) => {
  const body: HealthResponse = {
    status: 'ok',
    service: 'rigmart-server',
    version: '0.1.0',
    time: new Date().toISOString(),
  };
  res.json(body);
});
