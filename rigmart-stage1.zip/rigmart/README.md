# RIGMART

Премиальный интернет-магазин компьютерных комплектующих (страны Балтии).

## Структура

```
apps/web         сайт: React + Vite + Tailwind
apps/server      API: Node.js + Express
packages/shared  общий код: языки, страны, цены, типы API
.devcontainer    окружение Codespaces + PostgreSQL
```

## Команды (из корня проекта)

| Команда | Что делает |
|---|---|
| `npm install` | устанавливает зависимости (в Codespaces выполняется автоматически) |
| `npm run dev` | запускает сайт (порт 5173) и API (порт 4000) |
| `npm run check` | полная проверка: линтер + типы + сборка |
| `npm run lint` | проверка стиля кода |
| `npm run typecheck` | проверка типов TypeScript |
| `npm run build` | production-сборка |
| `npm run format` | автоформатирование кода |

## Этапы

- [x] 1. Фундамент: монорепозиторий, Codespaces, PostgreSQL, TypeScript strict, линтер
- [ ] 2. Дизайн-система, Header/Footer, i18n и языковые URL
- [ ] 3. Hero с 3D
- [ ] 4. Каталог на mock-данных
- [ ] 5. Страница товара и SEO
- [ ] 6. Корзина и избранное
- [ ] 7. Backend: Prisma, API
- [ ] 8. Checkout
- [ ] 9. Профиль и авторизация
- [ ] 10. Полировка
