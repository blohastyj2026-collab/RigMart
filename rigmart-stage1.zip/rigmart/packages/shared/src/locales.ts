/**
 * Языки сайта. Порядок = порядок в переключателе языка.
 * Чтобы добавить язык: добавить код сюда + папку переводов в apps/web.
 */
export const SUPPORTED_LOCALES = ['en', 'ru', 'lv', 'lt', 'et'] as const;

export type Locale = (typeof SUPPORTED_LOCALES)[number];

/** Язык по умолчанию: сюда редиректим с адреса без префикса. */
export const DEFAULT_LOCALE: Locale = 'en';

/** Полные коды для Intl (форматирование цен, дат) и тега hreflang. */
export const LOCALE_REGION: Record<Locale, string> = {
  en: 'en-IE',
  ru: 'ru-RU',
  lv: 'lv-LV',
  lt: 'lt-LT',
  et: 'et-EE',
};

/** Название языка на самом этом языке — для переключателя. */
export const LOCALE_NATIVE_NAME: Record<Locale, string> = {
  en: 'English',
  ru: 'Русский',
  lv: 'Latviešu',
  lt: 'Lietuvių',
  et: 'Eesti',
};

export function isLocale(value: unknown): value is Locale {
  return typeof value === 'string' && (SUPPORTED_LOCALES as readonly string[]).includes(value);
}

/**
 * Подбирает поддерживаемый язык по списку языков браузера
 * (например ['lv-LV', 'en-US']). Используется только как подсказка:
 * адрес страницы всегда остаётся явным (/en/, /lv/ ...).
 */
export function matchLocale(candidates: readonly string[]): Locale | null {
  for (const candidate of candidates) {
    const base = candidate.toLowerCase().split('-')[0];
    if (isLocale(base)) return base;
  }
  return null;
}
