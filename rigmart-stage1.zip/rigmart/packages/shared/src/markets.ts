/**
 * Страны доставки. Новая страна = новая запись здесь
 * (+ способы доставки в базе), без переписывания checkout.
 */
export const MARKET_COUNTRIES = ['LV', 'LT', 'EE'] as const;

export type CountryCode = (typeof MARKET_COUNTRIES)[number];

export function isMarketCountry(value: unknown): value is CountryCode {
  return (
    typeof value === 'string' && (MARKET_COUNTRIES as readonly string[]).includes(value)
  );
}
