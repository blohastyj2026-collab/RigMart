/** Общие типы ответов API — одинаковые для сервера и сайта. */

export interface HealthResponse {
  status: 'ok';
  service: 'rigmart-server';
  version: string;
  time: string;
}

export interface ApiError {
  error: {
    code: string;
    message: string;
  };
}
