import { LOCALE_REGION, type Locale } from './locales.js';

export type CurrencyCode = 'EUR';

export const DEFAULT_CURRENCY: CurrencyCode = 'EUR';

/**
 * Деньги всегда хранятся целым числом в минимальных единицах (центах):
 * 1999.00 € -> 199900. Так нет ошибок округления дробных чисел.
 */
export type Cents = number;

const formatters = new Map<string, Intl.NumberFormat>();

function getFormatter(locale: Locale, currency: CurrencyCode): Intl.NumberFormat {
  const key = `${locale}:${currency}`;
  let formatter = formatters.get(key);
  if (!formatter) {
    formatter = new Intl.NumberFormat(LOCALE_REGION[locale], {
      style: 'currency',
      currency,
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
    formatters.set(key, formatter);
  }
  return formatter;
}

/** 199900 -> "1 999,00 €" (lv) или "€1,999.00" (en). */
export function formatPrice(
  amount: Cents,
  locale: Locale,
  currency: CurrencyCode = DEFAULT_CURRENCY,
): string {
  if (!Number.isInteger(amount)) {
    throw new TypeError(`formatPrice expects integer cents, got ${amount}`);
  }
  return getFormatter(locale, currency).format(amount / 100);
}

/** Для ввода в админке: 1999.99 -> 199999. */
export function toCents(value: number): Cents {
  return Math.round(value * 100);
}
